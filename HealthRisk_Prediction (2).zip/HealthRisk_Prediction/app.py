import os
import logging
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Add this at the very top of your file, before other imports

from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os
from sklearn.neighbors import KNeighborsClassifier
from datetime import datetime
import pyttsx3
import threading
import speech_recognition as sr  # Import speech recognition
import matplotlib.pyplot as plt
import io
import base64
import tensorflow as tf  # Import TensorFlow
import csv
import traceback

app = Flask(__name__)

# Initialize the text-to-speech engine
engine = pyttsx3.init()

# Path to CSV file
csv_file = 'patients_data.csv'

# Ensure CSV file exists with correct headers
if not os.path.exists(csv_file):
    with open(csv_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['timestamp', 'name', 'age', 'medications', 'surgeries', 'health_events'])

# Function to train a KNN model
def train_knn_model():
    data = {
        'age': [25, 30, 35, 40, 45, 50, 55, 60],
        'medications': [1, 2, 2, 3, 3, 4, 4, 5],
        'risk': [0, 0, 1, 1, 1, 2, 2, 2]  # 0: Low, 1: Medium, 2: High
    }
    df = pd.DataFrame(data)
    X = df[['age', 'medications']]
    y = df['risk']
    model = KNeighborsClassifier(n_neighbors=3)
    model.fit(X, y)
    return model

# Train the model once when the application starts
knn_model = train_knn_model()

# Route to render HTML form
@app.route('/')
def patient_form():
    success = request.args.get('success', False)
    return render_template('patient_form.html', success=success)

# Function to handle text-to-speech in a separate thread
def speak(announcement):
    engine.say(announcement)
    engine.runAndWait()
def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()  # Make sure the event loop completes before continuing

# Route to handle form submission and save data to CSV
@app.route('/save', methods=['POST'])
def save_data():
    try:
        name = request.form['name']
        age = int(request.form['age'])
        medications = int(request.form['medications'])
        surgeries = request.form['surgeries']
        health_events = request.form['health_events']
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Create new file with headers if it doesn't exist
        if not os.path.exists(csv_file):
            with open(csv_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['timestamp', 'name', 'age', 'medications', 'surgeries', 'health_events'])
        
        # Append the data
        with open(csv_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([timestamp, name, age, medications, surgeries, health_events])

        print(f"Saved data: {[timestamp, name, age, medications, surgeries, health_events]}")

        # Predict health risk using the KNN model
        prediction = knn_model.predict([[age, medications]])
        risk_level = {0: "Low", 1: "Medium", 2: "High"}
        health_risk = risk_level[prediction[0]]

        # Announce success
        announcement = f"Patient {name} has been captured successfully."
        threading.Thread(target=speak, args=(announcement,)).start()

        return redirect(url_for('display_health_risk', name=name, age=age, health_risk=health_risk))

    except Exception as e:
        print(f"Error saving data: {str(e)}")
        traceback.print_exc()
        return f"Error saving data: {str(e)}", 500

# Route to display health risk
@app.route('/health_risk')
def display_health_risk():
    name = request.args.get('name')
    age = request.args.get('age')
    health_risk = request.args.get('health_risk')
    return render_template('health_risk.html', name=name, age=age, health_risk=health_risk)

# Route to display all patient data with search and pagination
@app.route('/view_patients', methods=['GET', 'POST'])
def view_patients():
    try:
        # Check if file exists and is not empty
        if not os.path.exists(csv_file):
            print("CSV file does not exist")
            return render_template('view_patients.html', 
                                 patients=pd.DataFrame(), 
                                 page=1, 
                                 total_pages=1,
                                 name_search=None,
                                 age_search=None,
                                 error="No patient records found.")
        
        # Read file contents for debugging
        with open(csv_file, 'r') as f:
            print("Raw CSV contents:")
            print(f.read())
        
        # Read the CSV file
        df = pd.read_csv(csv_file, header=None)  # Read without assuming headers
        
        # If first row contains headers, remove it
        if df.iloc[0].str.contains('timestamp|name|age|medications|surgeries|health_events').any():
            df = df.iloc[1:]  # Skip the header row
        
        # Assign column names
        df.columns = ['timestamp', 'name', 'age', 'medications', 'surgeries', 'health_events']
        
        print("DataFrame after reading:")
        print(df)
        print("Number of records:", len(df))
        print("Columns:", df.columns.tolist())

        if df.empty:
            print("DataFrame is empty")
            return render_template('view_patients.html', 
                                 patients=pd.DataFrame(), 
                                 page=1, 
                                 total_pages=1,
                                 name_search=None,
                                 age_search=None,
                                 error="No records found in the database.")

        # Convert age and medications to numeric
        df['age'] = pd.to_numeric(df['age'], errors='coerce')
        df['medications'] = pd.to_numeric(df['medications'], errors='coerce')

        # Apply filters
        name_search = request.form.get('name_search')
        age_search = request.form.get('age_search')
        
        if name_search:
            df = df[df['name'].str.contains(name_search, case=False, na=False)]
        if age_search:
            try:
                df = df[df['age'] == int(age_search)]
            except ValueError:
                pass

        # Sort by timestamp in descending order (newest first)
        try:
            # Try multiple timestamp formats
            df['timestamp'] = pd.to_datetime(df['timestamp'], format='mixed')
        except Exception as e:
            print(f"Error converting timestamp: {e}")
            # If conversion fails, just use the original string
            pass

        df = df.sort_values('timestamp', ascending=False)

        # Pagination
        page = int(request.args.get('page', 1))
        per_page = 10
        total_records = len(df)
        total_pages = max(1, (total_records + per_page - 1) // per_page)
        page = min(max(1, page), total_pages)

        start = (page - 1) * per_page
        end = start + per_page
        displayed_patients = df.iloc[start:end]

        print("Final displayed patients:")
        print(displayed_patients)

        return render_template('view_patients.html', 
                             patients=displayed_patients, 
                             page=page, 
                             total_pages=total_pages,
                             name_search=name_search, 
                             age_search=age_search)

    except Exception as e:
        print(f"Error in view_patients: {str(e)}")
        traceback.print_exc()
        return render_template('view_patients.html', 
                             patients=pd.DataFrame(), 
                             page=1, 
                             total_pages=1,
                             name_search=None,
                             age_search=None,
                             error=f"Error loading patient records: {str(e)}")

# New route for Speech Recognition
@app.route('/speech_recognition', methods=['GET', 'POST'])
def speech_recognition():
    if request.method == 'POST':
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("Please say something:")
            audio = recognizer.listen(source)
            try:
                spoken_text = recognizer.recognize_google(audio)
                print(f"You said: {spoken_text}")
                return render_template('speech_recognition.html', spoken_text=spoken_text)
            except sr.UnknownValueError:
                return "Sorry, I could not understand the audio."
            except sr.RequestError:
                return "Could not request results from the speech recognition service."

    return render_template('speech_recognition.html')

# New route for Time Series Analysis
@app.route('/time_series_analysis')
def time_series_analysis():
    try:
        if not os.path.exists(csv_file):
            return render_template('time_series_analysis.html', 
                                 error="No patient records found.")
        
        # Read the CSV file
        df = pd.read_csv(csv_file, header=None)  # Read without assuming headers
        
        # If first row contains headers, remove it
        if df.iloc[0].str.contains('timestamp|name|age|medications|surgeries|health_events').any():
            df = df.iloc[1:]  # Skip the header row
        
        # Assign column names
        df.columns = ['timestamp', 'name', 'age', 'medications', 'surgeries', 'health_events']

        # Convert timestamp to datetime
        try:
            df['timestamp'] = pd.to_datetime(df['timestamp'], format='mixed')
        except Exception as e:
            print(f"Error converting timestamp: {e}")
            return render_template('time_series_analysis.html', 
                                 error="Error processing timestamp data")

        # Group by date and count entries
        time_series_data = df.groupby(df['timestamp'].dt.date).size()

        # Create the plot
        plt.figure(figsize=(10, 5))
        time_series_data.plot(kind='line')
        plt.title('Patient Entries Over Time')
        plt.xlabel('Date')
        plt.ylabel('Number of Patients')
        
        # Convert plot to base64 image
        img = io.BytesIO()
        plt.savefig(img, format='png')
        plt.close()
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()

        return render_template('time_series_analysis.html', plot_url=plot_url)

    except Exception as e:
        print(f"Error in time_series_analysis: {str(e)}")
        traceback.print_exc()
        return render_template('time_series_analysis.html', 
                             error=f"Error generating time series analysis: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)
